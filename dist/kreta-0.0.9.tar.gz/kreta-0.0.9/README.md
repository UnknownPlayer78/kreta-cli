# kreta-cli
[![License MIT](https://img.shields.io/badge/License-MIT-brightgreen?style=for-the-badge)](https://mit-license.org/)
[![Python 3](https://img.shields.io/badge/Python-3-blue?style=for-the-badge)](https://www.python.org/)
[![PyPi 0.0.9](https://img.shields.io/badge/PyPi-0.0.9-blue?style=for-the-badge)](https://pypi.org/project/kreta/)

### KRÉTA Ellenőrző CLI

```
                                                  ____
                                                  \  /
                                                   \/
                                 _  __  _____    ______   _______
                                | |/ / |  __ \  |  ____| |__   __|  /\
                                |   /  | |__) | | |__       | |    /  \
                                |  (   |  _  /  |  __|      | |   / /\ \
                                |   \  | | \ \  | |____     | |  / /  \ \
                                |_|\_\ |_|  \_\ |______|    |_| /_/    \_\
                                                    
                                                   /\
                                                  /  \
                                                  ̅ ̅ ̅ ̅ ̅
```

<br>

## Installation:
```
pip install kreta
```
