import kreta
import sys

kreta.main(sys.argv)